from PIL import Image
import os

# 设置图片文件夹路径和输出的 GIF 文件名
image_folder = 'output'
output_gif = 'output.gif'

# 获取图片文件夹中所有的 JPG 图片
image_files = [f for f in os.listdir(image_folder) if f.endswith('.jpg')]

# 打开第一张图片，准备创建 GIF 动图
img, *imgs = [Image.open(os.path.join(image_folder, f)) for f in image_files]

# 保存为 GIF 动图
img.save(fp=output_gif, format='GIF', append_images=imgs,
         save_all=True, duration=300, loop=1)
